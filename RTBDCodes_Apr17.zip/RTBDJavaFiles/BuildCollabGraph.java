package javaCodes;

//import java.io.BufferedReader;
import java.io.FileNotFoundException;
//import java.io.FileReader;

public class BuildCollabGraph {
	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		//BufferedReader br = new BufferedReader(new FileReader("..\\..\\RTBDData\\oaiharvesterdemo\\citeseerx_alldata_small.xml"));
	}
}
