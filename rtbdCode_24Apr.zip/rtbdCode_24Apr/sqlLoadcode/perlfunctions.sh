#!/usr/bin/perl
print "called";
print "$text";
