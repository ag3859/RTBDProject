#!/bin/bash
while read line
do 
	./perlfunctions.sh -x -text=$line
done < $1
