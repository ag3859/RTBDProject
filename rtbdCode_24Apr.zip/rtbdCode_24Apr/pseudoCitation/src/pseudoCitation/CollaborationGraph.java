package pseudoCitation;

import java.util.HashMap;

public class CollaborationGraph {

	HashMap <String,Integer> author;
	/**
	 * Function to add to the graph given list of authors of a paper
	 */
	//addPaperAuthors(ArrayList <String> ())
	//for each author:
	//	lookUpAuthor in hashmap. If found, then update adjacency list based on 
	//	other authors. Else get a new id, insert into hashmap, and update 
	//  adjacency list
	//	
	
	
	/**
	 * Count the collaboration distance between two authors
	 */
	//getCollaborationDistance(author1,author2)
	//Returns distance if found both authors, -1 otherwise
	//will implement a DFS for this
	
	
	
	/**
	 * Function to read in graph from text file and put into arraylist
	 */
	//readGraph(String inputfilename)
	/*Graph will be an arraylist of arraylist<integer>*/
	/*Each author will be assigned his unique id*/
}
