package pseudoCitation;

public class DataProcessing {
	/**
	 * Function to parse data from Citeseer/DBLP database
	 * papername, authorlist, citations, conference, year
	 */
	
	/**
	 * Function to clean up authornames - in case of duplicates, 
	 * spellings, other order of names etc
	 */
	
	/**
	 * Function to clean up papername (if required)
	 * Need to test that papername is same in the metadata as 
	 * well as in the citation data of other papers
	 */
	
	
	/**
	 * Function to retrieve list of citations in a given paper
	 */
	
	/**
	 * Function to retrieve list of authors for a given paper
	 */
	
	/**
	 * Function to retrieve list of papers for a given conference
	 */
	
	
	
	
}
